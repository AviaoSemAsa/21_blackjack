############### Jogo de carta 21(black jack) #####################
#Made by Gustavo Machado

import random

def checas_as(jogador1):
  if 11 in jogador1:
    if sum(jogador1) > 21:
      jogador1[jogador1.index(11)] = 1
    return jogador1


def vencedor(jogador1, dealer, saldo, aposta):
  if sum(jogador1) > sum(dealer):
    print(f"\n\n\nParabens voce venceu!!\ndealer: {dealer}, voce: {jogador1}\n")  
    return saldo+aposta
  elif sum(jogador1) == sum(dealer):
    print(f"\n\nEmpate!!! \ndealer: {dealer}, voce: {jogador1}\n")
    return saldo

  else:
    print(f"\n\n\ninfelizmente voce perdeu :(\ndealer: {dealer}, voce: {jogador1}\n")
    return saldo - aposta

def imprime(jogador1, dealer):
  print(f"Dealer: ?, {dealer[0]}\nVoce: {jogador1}\n\n\n")

def passou_de_21(cartas):
  return sum(cartas) > 21

def compra_carta(cartas_atuais):
  x = random.choice(cartas)
  cartas_atuais.append(x)
  checas_as(jogador1)



def inicia_jogo(jogador1, dealer):
  compra_carta(jogador1)
  compra_carta(jogador1)
  compra_carta(dealer)
  compra_carta(dealer)

def continuar_a_jogar(continuar):
  return continuar == "sim"

def imprime_saldo(saldo):
  print(f"Seu saldo atual é de: {saldo}\n")

def aposta_valor(saldo):
    aposta = 0
    while aposta == 0:
      aposta = input("\n\nQuanto voce quer apostar?: ")
      if int(aposta) > saldo:
        print("\nVoce nao pode apostar mais do que tem!!!\n")
        aposta = 0
      else:
        aposta = int(aposta)
    return aposta


cartas = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]
jogador1 = []
dealer = []
continuar = True
apostar = True
saldo = 1000
aposta = 0


while apostar is True:
  jogador1.clear()
  dealer.clear()
  imprime_saldo(saldo)
  if saldo == 0:
    print("Voce perdeu tudo, nao tem mais o que apostar!!! HAHAHAHA")
    break
  inicia_jogo(jogador1, dealer)
  continuar = True
  aposta = aposta_valor(saldo)
  while continuar is True:
    imprime(jogador1, dealer)
    continuar = continuar_a_jogar(input("Quer comprar mais uma carta? sim ou não?: "))  
    if continuar:
      compra_carta(jogador1)    
      if passou_de_21(jogador1):
        print(f"\n\n{jogador1}, voce passou de 21. Você perdeu. \nO Dealer tinha: {dealer}\n")
        saldo -= aposta
        if input("Quer jogar novamente? sim ou nao?: ") == "nao":
          apostar is False
        break
    else:
      saldo = vencedor(jogador1, dealer, saldo, aposta)
      continuar = False
      imprime_saldo(saldo)
      if input("Quer jogar novamente? sim ou nao?: ") == "nao":
        apostar is False
